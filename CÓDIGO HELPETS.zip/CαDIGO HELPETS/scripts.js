document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Obrigado por entrar em contato! Responderemos em breve.');
});

const filterButtons = document.querySelectorAll('.filter-btn');
const petCards = document.querySelectorAll('.category-gallery .pet-card');

filterButtons.forEach(button => {
    button.addEventListener('click', () => {
        const category = button.getAttribute('data-category');
        petCards.forEach(card => {
            if (card.getAttribute('data-category') === category) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });
});

// inicialmente mostrar todos os animais
petCards.forEach(card => {
    card.style.display = 'block';
});



document.getElementById('filter-button').addEventListener('click', function() {
    // obbter os valores selecionados nos campos do formulário
    const selectedSpecies = document.getElementById('species').value;
    const selectedSize = document.getElementById('size').value;
    const selectedAge = document.getElementById('age').value;

    // obter todos os cards de animais da galeria
    const petCards = document.querySelectorAll('#gallery .pet-card');

    // ler sobre cada card de animal e aplicar o filtro
    petCards.forEach(card => {
        const species = card.getAttribute('data-species');
        const size = card.getAttribute('data-size');
        const age = card.getAttribute('data-age');

        // ver se o card atende aos critérios de filtro selecionados
        const showCard = (selectedSpecies === 'all' || selectedSpecies === species) &&
                        (selectedSize === 'all' || selectedSize === size) &&
                        (selectedAge === 'all' || selectedAge === age);

        // mostrar ou ocultar o card com base no resultado do filtro
        if (showCard) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
});

document.getElementById('register-button').addEventListener('click', function() {
    const name = document.getElementById('pet-name').value;
    const species = document.getElementById('pet-species').value;
    const size = document.getElementById('pet-size').value;
    const age = document.getElementById('pet-age').value;
    const image = document.getElementById('pet-image').files[0];

    if (!name || !species || !size || !age || !image) {
        alert('Por favor, preencha todos os campos.');
        return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
        const gallery = document.querySelector('#gallery .gallery');
        const card = document.createElement('div');
        card.className = 'pet-card';
        card.setAttribute('data-species', species);
        card.setAttribute('data-size', size);
        card.setAttribute('data-age', age);

        const img = document.createElement('img');
        img.src = e.target.result;
        img.alt = `${size} ${species} ${age}`;

        const p = document.createElement('p');
        p.textContent = `Nome: ${name}`;

        card.appendChild(img);
        card.appendChild(p);
        gallery.appendChild(card);
    };

    reader.readAsDataURL(image);
});
